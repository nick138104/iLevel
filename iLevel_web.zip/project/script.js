import { initializeApp } from "https://www.gstatic.com/firebasejs/9.8.1/firebase-app.js";
import { getDatabase, onValue, ref, set } from "https://www.gstatic.com/firebasejs/9.8.1/firebase-database.js";

const firebaseConfig = {
    apiKey: "AIzaSyD4jmia2xrkpuo_I25MZGm6uJgc4JihS9c",
    authDomain: "test-95a70.firebaseapp.com",
    databaseURL: "https://test-95a70-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "test-95a70",
    storageBucket: "test-95a70.appspot.com",
    messagingSenderId: "1000034832361",
    appId: "1:1000034832361:web:80f5bb39fba371d6378578"
};

var current_level;

var isFull = document.getElementById('isFull');
var temp = document.getElementById('temp');
var level = document.getElementById('level');
var icon = document.getElementById('icon-battery')
const app = initializeApp(firebaseConfig);
const db = getDatabase();
const reference = ref(db, 'main');


onValue(reference, (snapshot) => {
    const data = snapshot.val();
    if (data.is_full == 0) {
        isFull.innerText = 'NO';
        icon.name = 'battery-dead-outline';
    } else {
        isFull.innerText = 'YES';
        icon.name = 'battery-full-outline';
    }
    temp.innerText = data.temperature;
    level.innerText = data.water_level;
});

function writeUserData(userId, height) {
    const reference_user = ref(db, 'main/user/' + userId);
    set(reference_user, {
        level: height
    });
    current_level = height;
}

var form = document.getElementById('form-input');
form.addEventListener("submit", addbucket) 
function addbucket(event){
    event.preventDefault();
    const userId = document.getElementById('UserId');
    const height = document.getElementById('height');
    console.log(userId + height);
}